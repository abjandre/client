export abstract class Pessoa {

  id: number;

  nome: string;

  apelido: string;

  cgc: number;

  telefone: number;

  endereco: string;

  email: string;

  idCidade: number;
}

