import {Pessoa} from '../pessoa/pessoa';

export class Cliente extends Pessoa {

}
