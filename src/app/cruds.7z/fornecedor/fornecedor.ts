import {Pessoa} from '../pessoa/pessoa';

export class Fornecedor extends Pessoa {

}
